class E {
  int p13;
  int p12;
  int p3;
  int p4;
  int p15;
  long p22;
  long p21;
  long p37;
  int[] p39 = {-3, 2, -1, -2, -1};
  int[] p6 = {1, 3, 0, -1};
  int[] p27 = {-2, 0, 2, -3};
  static int p8;
  static int p25;
  static int p32;
  static int p31;
  static int p38;
  public E() {
    p13 = 0;
    p12 = 8;
    p3 = 1;
    p4 = 0;
    p15 = 4;
    p22 = 1L;
    p21 = 3L;
    p37 = 0L;
  }
  public void p5() {
    System.out.println("метод p5 в классе E");
    System.out.println(p15 - 3);
  }
  public void p23() {
    System.out.println("метод p23 в классе E");
    System.out.println(p4 << 1);
  }
  public void p2() {
    System.out.println("метод p2 в классе E");
    System.out.println(p3 + 5);
  }
  public void p24() {
    System.out.println("метод p24 в классе E");
    System.out.println(p4);
  }
  public void p18() {
    System.out.println("метод p18 в классе E");
    System.out.println(p3++);
  }
  public void p33() {
    System.out.println("метод p33 в классе E");
    System.out.println(p25++);
  }
  public static void p1() {
    System.out.println("метод p1 в классе E");
    System.out.println(p31);
  }
  public static void p7() {
    System.out.println("метод p7 в классе E");
    System.out.println((p31 - 4));
  }
  public static void p26() {
    System.out.println("метод p26 в классе E");
    System.out.println(p38);
  }
  public static void p9() {
    System.out.println("метод p9 в классе E");
    System.out.println((p38 + 2));
  }
  public void p30(E r) {
    r.p5();
  }
  public void p30(A r) {
    r.p23();
  }
}
