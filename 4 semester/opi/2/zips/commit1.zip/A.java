class A extends E {
  public A() {
    p12 = 1;
    p3 = 6;
    p4 = 4;
    p15 = 3;
  }
  public void p5() {
    System.out.println("метод p5 в классе A");
    System.out.println(p15);
  }
  public void p23() {
    System.out.println("метод p23 в классе A");
    System.out.println(p6[1] - p6[1]);
  }
  public void p2() {
    System.out.println("метод p2 в классе A");
    System.out.println(p27[1] - p27[1]);
  }
  public void p24() {
    System.out.println("метод p24 в классе A");
    System.out.println(p15 << 1);
  }
  public void p18() {
    System.out.println("метод p18 в классе A");
    System.out.println(p3);
  }
  public static void p1() {
    System.out.println("метод p1 в классе A");
    System.out.println(p25);
  }
  public static void p7() {
    System.out.println("метод p7 в классе A");
    System.out.println((p25 - 3));
  }
  public static void p26() {
    System.out.println("метод p26 в классе A");
    System.out.println(p25);
  }
  public static void p9() {
    System.out.println("метод p9 в классе A");
    System.out.println((p25 + 5));
  }
  public void p30(E r) {
    r.p2();
  }
  public void p30(A r) {
    r.p24();
  }
}
