// var. 560711
public class Lab4 {
  public static void main(String[] args) {
  E a = new E();
  E b = new A();
  A c = new A();
  b.p5();
  c.p23();
  b.p2();
  b.p24();
  b.p18();
  b.p33();
  b.p1();
  b.p7();
  a.p26();
  c.p9();
  a.p30(a);
  c.p30(b);
  b.p30(c);
  }
}
previous : 39
