use crate::isa::WordSize;
use crate::machine::nzcv::Nzcv;

#[derive(Clone)]
pub enum AluOperator {
    Add,
    Adc,
    Sub,
    Mul,
    Div,
    Rem,
    And,
    Or,
    Xor,
    Not,
    Lsl,
    Lsr,
    Asl,
    Asr,
    Trl,
    Trr,
}

pub struct Alu {
    pub nzcv: Nzcv,
}

impl Alu {
    pub fn new(nzcv: Nzcv) -> Self {
        Self { nzcv }
    }

    pub fn execute_operator(
        &mut self,
        operator: &AluOperator,
        word_size: &WordSize,
        a: u64,
        b: u64,
    ) -> u64 {
        let a = match word_size {
            WordSize::Byte => a & 0xFF,
            WordSize::Long => a,
        };
        let b = match word_size {
            WordSize::Byte => b & 0xFF,
            WordSize::Long => b,
        };

        let (result, negative, zero, carry, overflow) = match operator {
            AluOperator::Add => {
                let (result, carry) = a.overflowing_add(b);
                let overflow = (!(a ^ b) & (a ^ result)) >> 63 == 1;
                (
                    result,
                    Some(result >> 63 == 1),
                    Some(result == 0),
                    Some(carry),
                    Some(overflow),
                )
            }
            AluOperator::Adc => {
                let old_carry = self.nzcv.carry as u64;
                let full_result = (a as u128) + (b as u128) + (old_carry as u128);
                let result = full_result as u64;
                let carry = full_result > u64::MAX as u128;
                let overflow = (!(a ^ b) & (a ^ result)) >> 63 == 1;
                (
                    result,
                    Some(result >> 63 == 1),
                    Some(result == 0),
                    Some(carry),
                    Some(overflow),
                )
            }
            AluOperator::Sub => {
                let (result, carry) = a.overflowing_sub(b);
                let overflow = ((a ^ b) & (a ^ result)) >> 63 == 1;
                (
                    result,
                    Some(result >> 63 == 1),
                    Some(result == 0),
                    Some(carry),
                    Some(overflow),
                )
            }
            AluOperator::Mul => {
                let result = a.wrapping_mul(b);
                let carry = (a as u128 * b as u128) > (u64::MAX as u128);
                let full_result = (a as i64 as i128) * (b as i64 as i128);
                let overflow = full_result != (result as i64 as i128);
                (
                    result,
                    Some(result >> 63 == 1),
                    Some(result == 0),
                    Some(carry),
                    Some(overflow),
                )
            }
            AluOperator::Div => {
                if b == 0 {
                    (0u64, Some(false), Some(true), Some(true), Some(false))
                } else {
                    let (a_i, b_i) = (a as i64, b as i64);
                    if a_i == i64::MIN && b_i == -1 {
                        (a, Some(a >> 63 == 1), Some(a == 0), Some(false), Some(true))
                    } else {
                        let result = (a_i / b_i) as u64;
                        (
                            result,
                            Some(result >> 63 == 1),
                            Some(result == 0),
                            Some(false),
                            Some(false),
                        )
                    }
                }
            }
            AluOperator::Rem => {
                if b == 0 {
                    (0u64, Some(false), Some(true), Some(true), Some(false))
                } else {
                    let (a_i, b_i) = (a as i64, b as i64);
                    if a_i == i64::MIN && b_i == -1 {
                        (a, Some(false), Some(true), Some(false), Some(true))
                    } else {
                        let result = (a_i % b_i) as u64;
                        (
                            result,
                            Some(result >> 63 == 1),
                            Some(result == 0),
                            Some(false),
                            Some(false),
                        )
                    }
                }
            }
            AluOperator::And => (a & b, Some(a & b >> 63 == 1), Some(a & b == 0), None, None),
            AluOperator::Or => (a | b, Some(a | b >> 63 == 1), Some(a | b == 0), None, None),
            AluOperator::Xor => (a ^ b, Some(a ^ b >> 63 == 1), Some(a ^ b == 0), None, None),
            AluOperator::Not => (!b, Some(!b >> 63 == 1), Some(!b == 0), None, None),
            AluOperator::Lsl => {
                let shift_count = (b & 63) as u32;
                if shift_count == 0 {
                    (a, Some(a >> 63 == 1), Some(a == 0), None, None)
                } else {
                    let carry = (a >> (64 - shift_count)) & 1 == 1;
                    let result = a << shift_count;
                    (
                        result,
                        Some(result >> 63 == 1),
                        Some(result == 0),
                        Some(carry),
                        None,
                    )
                }
            }
            AluOperator::Lsr => {
                let shift_count = (b & 63) as u32;
                if shift_count == 0 {
                    (a, Some(a >> 63 == 1), Some(a == 0), None, None)
                } else {
                    let carry = (a >> (shift_count - 1)) & 1 == 1;
                    let result = a >> shift_count;
                    (
                        result,
                        Some(result >> 63 == 1),
                        Some(result == 0),
                        Some(carry),
                        None,
                    )
                }
            }
            AluOperator::Asl => {
                let shift_count = (b & 63) as u32;
                (
                    a << shift_count,
                    Some((a << shift_count) >> 63 == 1),
                    Some((a << shift_count) == 0),
                    None,
                    None,
                )
            }
            AluOperator::Asr => {
                let shift_count = (b & 63) as u32;
                let result = ((a as i64) >> shift_count) as u64;
                (
                    result,
                    Some(result >> 63 == 1),
                    Some(result == 0),
                    None,
                    None,
                )
            }
            AluOperator::Trl => (a, None, None, None, None),
            AluOperator::Trr => (b, None, None, None, None),
        };
        self.set_flags(negative, zero, carry, overflow);
        result
    }

    fn set_flags(
        &mut self,
        negative: Option<bool>,
        zero: Option<bool>,
        carry: Option<bool>,
        overflow: Option<bool>,
    ) {
        if let Some(negative) = negative {
            self.nzcv.negative = negative;
        }
        if let Some(zero) = zero {
            self.nzcv.zero = zero;
        }
        if let Some(carry) = carry {
            self.nzcv.carry = carry;
        }
        if let Some(overflow) = overflow {
            self.nzcv.overflow = overflow;
        }
    }
}

impl Default for Alu {
    fn default() -> Self {
        Self::new(Nzcv::default())
    }
}
