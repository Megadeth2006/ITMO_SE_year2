use crate::translator::common::ResBox;
use regex::Regex;

#[derive(Debug)]
pub enum SyntaxNode {
    If {
        condition: String,
    },
    ElseIf {
        condition: String,
    },
    Else,
    While {
        condition: String,
    },
    For {
        condition: String,
    },
    Function {
        result_type: String,
        name: String,
        arguments: String,
    },
    Class {
        name: String,
    },
    Line {
        value: String,
    },
    Scope,
    File,
}

#[derive(Debug)]
pub struct SyntaxTree {
    pub node: SyntaxNode,
    pub children: Vec<SyntaxTree>,
}

impl SyntaxTree {
    pub fn new(node: SyntaxNode) -> Self {
        SyntaxTree {
            node,
            children: Vec::new(),
        }
    }
}

pub fn parse_syntax_tree(code: &str) -> ResBox<SyntaxTree> {
    let if_pattern = Regex::new(r"^if\s*\((.+)\)")?;
    let else_if_pattern = Regex::new(r"^else\s+if\s*\((.+)\)")?;
    let else_pattern = Regex::new(r"^else")?;
    let while_pattern = Regex::new(r"^while\s*\((.+)\)")?;
    let for_pattern = Regex::new(r"^for\s*\((.+)\)")?;
    let function_pattern = Regex::new(r"^(\w+)\s+(\w+)\s*\(([^)]*)\)")?;
    let class_pattern = Regex::new(r"^class\s+(\w+)")?;

    let tokens = get_tokens(code)?;
    let mut tree_stack: Vec<SyntaxTree> = vec![SyntaxTree::new(SyntaxNode::File)];
    let mut expect_body = false;

    for token in tokens.iter() {
        if token == "{" {
            if expect_body {
                expect_body = false;
            } else {
                tree_stack.push(SyntaxTree::new(SyntaxNode::Scope));
            }
        } else if token == "}" {
            if tree_stack.len() < 2 {
                return Err("Unmatched closing bracket".into());
            }
            let current_tree = tree_stack.pop().unwrap();
            tree_stack.last_mut().unwrap().children.push(current_tree);
        } else if let Some(captures) = if_pattern.captures(token) {
            let condition = captures.get(1).unwrap().as_str().to_string();
            tree_stack.push(SyntaxTree::new(SyntaxNode::If { condition }));
            expect_body = true;
        } else if let Some(captures) = else_if_pattern.captures(token) {
            let condition = captures.get(1).unwrap().as_str().to_string();
            tree_stack.push(SyntaxTree::new(SyntaxNode::ElseIf { condition }));
            expect_body = true;
        } else if else_pattern.is_match(token) {
            tree_stack.push(SyntaxTree::new(SyntaxNode::Else));
            expect_body = true;
        } else if let Some(captures) = while_pattern.captures(token) {
            let condition = captures.get(1).unwrap().as_str().to_string();
            tree_stack.push(SyntaxTree::new(SyntaxNode::While { condition }));
            expect_body = true;
        } else if let Some(captures) = for_pattern.captures(token) {
            let condition = captures.get(1).unwrap().as_str().to_string();
            tree_stack.push(SyntaxTree::new(SyntaxNode::For { condition }));
            expect_body = true;
        } else if let Some(captures) = function_pattern.captures(token) {
            let result_type = captures
                .get(1)
                .map(|m| m.as_str())
                .expect("Function result type expected")
                .to_string();
            let name = captures
                .get(2)
                .map(|m| m.as_str())
                .unwrap_or("")
                .to_string();
            let arguments = captures
                .get(3)
                .map(|m| m.as_str())
                .unwrap_or("")
                .to_string();
            tree_stack.push(SyntaxTree::new(SyntaxNode::Function {
                result_type,
                name,
                arguments,
            }));
            expect_body = true;
        } else if let Some(captures) = class_pattern.captures(token) {
            let name = captures.get(1).unwrap().as_str().to_string();
            tree_stack.push(SyntaxTree::new(SyntaxNode::Class { name }));
            expect_body = true;
        } else if token.ends_with(';') {
            let value = token.trim_end_matches(';').trim().to_string();
            tree_stack
                .last_mut()
                .unwrap()
                .children
                .push(SyntaxTree::new(SyntaxNode::Line { value }));
        } else {
            return Err("Wrong syntax".into());
        }
    }

    if tree_stack.len() != 1 {
        return Err("Unclosed brackets".into());
    }

    tree_stack
        .pop()
        .ok_or_else(|| "Syntax tree is empty".into())
}

fn get_tokens(code: &str) -> ResBox<Vec<String>> {
    let mut sentences = vec![];
    let mut token = String::new();
    let mut depth = 0;

    for c in code.chars() {
        match c {
            '(' => {
                depth += 1;
                token.push(c);
            }
            ')' => {
                if depth == 0 {
                    return Err("Unmatched closing bracket".into());
                }
                depth -= 1;
                token.push(c);
            }
            '{' | '}' => {
                if !token.trim().is_empty() {
                    sentences.push(token.trim().to_string());
                }
                sentences.push(c.to_string());
                token = String::new();
            }
            ';' => {
                if token.trim().is_empty() {
                    token = String::new();
                    continue;
                }
                token.push(c);
                if depth == 0 {
                    sentences.push(token.trim().to_string());
                    token = String::new();
                }
            }
            _ => token.push(c),
        }
    }

    if !token.trim().is_empty() {
        sentences.push(token.trim().to_string());
    }

    Ok(sentences)
}
