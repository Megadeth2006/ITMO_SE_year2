use crate::isa::WordSize;
use crate::translator::common::{Address, Type};
use crate::translator::hir::{
    BlockId, ControlFlowGraph, GlobalId, HirBinaryOperator, HirBlock, HirInstruction, HirOperand,
    HirRegister, HirTerminator, StackSlot,
};
use std::collections::{HashMap, hash_map};
use std::vec;

#[derive(Debug, Clone)]
pub struct ArrayConstant {
    pub values: Vec<String>,
    pub element_type: Type,
    pub base_address: Address,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RegisterType {
    Data,
    Address,
}

#[derive(Debug, Clone)]
pub enum LirOperand {
    Direct(u64),
    VirtualRegister(usize, RegisterType),
    Register(u8, RegisterType),
    Indirect(Box<LirOperand>),
    IndirectPostIncrement(Box<LirOperand>),
    IndirectPreDecrement(Box<LirOperand>),
    IndirectOffset {
        base: Box<LirOperand>,
        offset: Box<LirOperand>,
    },
    IndirectDirect(Address),
}

#[derive(Debug, Clone)]
pub enum Condition {
    Equal,
    NotEqual,
    Greater,
    GreaterEqual,
    Lower,
    LowerEqual,
    CarrySet,
    CarryClear,
    OverflowSet,
    OverflowClear,
}

#[derive(Debug, Clone)]
pub enum LirInstruction {
    Mov {
        size: WordSize,
        source: LirOperand,
        destination: LirOperand,
    },
    Cmp {
        size: WordSize,
        that: LirOperand,
        with: LirOperand,
    },
    Add {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Sub {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Mul {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Div {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Rem {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },

    Lsl {
        size: WordSize,
        source: LirOperand,
        count: LirOperand,
        destination: LirOperand,
    },
    Lsr {
        size: WordSize,
        source: LirOperand,
        count: LirOperand,
        destination: LirOperand,
    },

    And {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Or {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Xor {
        size: WordSize,
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Not {
        size: WordSize,
        source: LirOperand,
        destination: LirOperand,
    },
    Jmp {
        label: BlockId,
    },
    Branch {
        condition: Condition,
        label: BlockId,
    },
    VAdd {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VSub {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VMul {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VDiv {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VRem {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VAnd {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VOr {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VXor {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VCmpBeq {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VCmpBne {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VCmpBgt {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VCmpBge {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VCmpBlt {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    VCmpBle {
        left: LirOperand,
        right: LirOperand,
        destination: LirOperand,
    },
    Call {
        label: BlockId,
    },
    Ret,
    IntRet,
    In {
        port: LirOperand,
        destination: LirOperand,
        word_size: WordSize,
    },
    Out {
        port: LirOperand,
        value: LirOperand,
        word_size: WordSize,
    },
    Halt,
    SetBool {
        condition: Condition,
        destination: LirOperand,
    },
    AllocateStackFrame,
}

#[derive(Debug, Clone)]
pub struct LirBlock {
    pub id: BlockId,
    pub instructions: Vec<LirInstruction>,
}

pub struct LirContext {
    virtual_register_counter: u64,

    pub block_to_function: HashMap<BlockId, BlockId>,
    pub register_to_function: HashMap<usize, BlockId>,

    pub blocks: Vec<LirBlock>,

    stack_offsets: HashMap<StackSlot, i64>,
    pub frame_sizes: HashMap<BlockId, i64>,
    current_function: Option<BlockId>,

    pub data_size: u64,
    pub constants: HashMap<(String, Type), (Address, WordSize)>,

    pub globals: HashMap<GlobalId, Address>,

    pub array_constants: Vec<ArrayConstant>,

    return_registers: LirOperand,

    pub restore_data_registers: Vec<LirOperand>,
    pub restore_address_registers: Vec<LirOperand>,

    heap_pointer: LirOperand,
    pub frame_pointer: LirOperand,
    pub stack_pointer: LirOperand,

    pub allocated_data_registers: HashMap<usize, u8>,
    pub allocated_address_registers: HashMap<usize, u8>,

    pub spilled_data_registers: HashMap<usize, i64>,
    pub spilled_address_registers: HashMap<usize, i64>,

    saved_registers: Vec<LirOperand>,
}

impl LirContext {
    fn new(register_counter: u64) -> Self {
        Self {
            virtual_register_counter: register_counter,
            block_to_function: HashMap::new(),
            register_to_function: HashMap::new(),
            blocks: vec![],
            frame_sizes: HashMap::new(),
            stack_offsets: HashMap::new(),
            current_function: None,
            data_size: 0,
            constants: HashMap::new(),
            globals: HashMap::new(),
            array_constants: vec![],
            return_registers: LirOperand::Register(0, RegisterType::Data),
            restore_data_registers: vec![
                LirOperand::Register(5, RegisterType::Data),
                LirOperand::Register(6, RegisterType::Data),
                LirOperand::Register(7, RegisterType::Data),
            ],
            restore_address_registers: vec![
                LirOperand::Register(2, RegisterType::Address),
                LirOperand::Register(3, RegisterType::Address),
                LirOperand::Register(4, RegisterType::Address),
            ],
            heap_pointer: LirOperand::Register(5, RegisterType::Address),
            frame_pointer: LirOperand::Register(6, RegisterType::Address),
            stack_pointer: LirOperand::Register(7, RegisterType::Address),
            allocated_data_registers: HashMap::new(),
            allocated_address_registers: HashMap::new(),
            spilled_data_registers: HashMap::new(),
            spilled_address_registers: HashMap::new(),
            saved_registers: vec![
                LirOperand::Register(1, RegisterType::Data),
                LirOperand::Register(2, RegisterType::Data),
                LirOperand::Register(3, RegisterType::Data),
                LirOperand::Register(4, RegisterType::Data),
                LirOperand::Register(0, RegisterType::Address),
                LirOperand::Register(1, RegisterType::Address),
            ],
        }
    }

    fn new_virtual_data_register(&mut self) -> LirOperand {
        let register = self.virtual_register_counter;
        self.virtual_register_counter += 1;
        LirOperand::VirtualRegister(register as usize, RegisterType::Data)
    }

    fn new_virtual_address_register(&mut self) -> LirOperand {
        let register = self.virtual_register_counter;
        self.virtual_register_counter += 1;
        LirOperand::VirtualRegister(register as usize, RegisterType::Address)
    }

    fn get_virtual_register(&mut self, operand: HirOperand) -> LirOperand {
        match operand {
            HirOperand::Value(register) => self.get_virtual_data_register(register),
            HirOperand::Link(register) => self.get_virtual_address_register(register),
            _ => panic!("Virtual register called for non-register"),
        }
    }

    fn get_virtual_data_register(&mut self, register: HirRegister) -> LirOperand {
        if let Some(function) = self.current_function {
            self.register_to_function
                .insert(register.0 as usize, function);
        }
        LirOperand::VirtualRegister(register.0 as usize, RegisterType::Data)
    }

    fn get_virtual_address_register(&mut self, register: HirRegister) -> LirOperand {
        if let Some(function) = self.current_function {
            self.register_to_function
                .insert(register.0 as usize, function);
        }
        LirOperand::VirtualRegister(register.0 as usize, RegisterType::Address)
    }

    fn get_constant_address(&mut self, value: String, typ: Type) -> Address {
        let word_size = match typ {
            Type::Int => WordSize::Long,
            Type::Bool | Type::Char => WordSize::Byte,
            _ => unreachable!(),
        };

        if let Some((address, size)) = self.constants.get(&(value.clone(), typ.clone()))
            && *size == word_size
        {
            *address
        } else {
            let address = self.data_size;

            self.constants
                .insert((value, typ), (address, word_size.clone()));
            self.data_size += 1;
            address
        }
    }

    fn get_global_address(&mut self, id: GlobalId) -> Address {
        if let Some(address) = self.globals.get(&id) {
            *address
        } else {
            let address = self.data_size;
            self.globals.insert(id, address);
            self.data_size += 1;
            address
        }
    }

    fn save_registers(&mut self, out: &mut Vec<LirInstruction>) {
        for register in &self.saved_registers {
            out.push(LirInstruction::Mov {
                size: WordSize::Long,
                source: register.clone(),
                destination: LirOperand::IndirectPreDecrement(Box::new(self.stack_pointer.clone())),
            });
        }
    }

    fn restore_registers(&mut self, out: &mut Vec<LirInstruction>) {
        for register in self.saved_registers.iter().rev() {
            out.push(LirInstruction::Mov {
                size: WordSize::Long,
                source: LirOperand::IndirectPostIncrement(Box::new(self.stack_pointer.clone())),
                destination: register.clone(),
            });
        }
    }

    fn operand_to_register(
        &mut self,
        operand: LirOperand,
        register_type: RegisterType,
        out: &mut Vec<LirInstruction>,
    ) -> LirOperand {
        if let LirOperand::VirtualRegister(_, _) = &operand {
            return operand;
        }

        let temp = match register_type {
            RegisterType::Address => self.new_virtual_address_register(),
            RegisterType::Data => self.new_virtual_data_register(),
        };
        out.push(LirInstruction::Mov {
            size: WordSize::Long,
            source: operand,
            destination: temp.clone(),
        });
        temp
    }

    fn lower_operand(&mut self, operand: HirOperand) -> LirOperand {
        match operand {
            HirOperand::Value(register) => self.get_virtual_data_register(register),
            HirOperand::Link(register) => self.get_virtual_address_register(register),
            HirOperand::Constant(value_str, typ) => {
                let normalized_value = normalize_constant(value_str);
                let address = self.get_constant_address(normalized_value, typ);
                LirOperand::IndirectDirect(address)
            }
            HirOperand::Variable(slot) => {
                let offset = *self.stack_offsets.get(&slot).unwrap() as u64;
                LirOperand::IndirectOffset {
                    base: Box::new(self.frame_pointer.clone()),
                    offset: Box::new(LirOperand::Direct(offset)),
                }
            }
            HirOperand::Parameter(offset) => LirOperand::IndirectOffset {
                base: Box::new(self.frame_pointer.clone()),
                offset: Box::new(LirOperand::Direct(offset)),
            },
            HirOperand::GlobalVariable(id) => {
                let address = self.get_global_address(id);
                LirOperand::IndirectDirect(address)
            }
            HirOperand::Void => panic!("Cannot lower void operand"),
        }
    }

    fn lower(&mut self, hir_blocks: Vec<HirBlock>) {
        self.current_function = None;

        for hir_block in &hir_blocks {
            if hir_block.instructions.iter().any(|i| {
                matches!(
                    i,
                    HirInstruction::CallPrologue | HirInstruction::InterruptPrologue
                )
            }) {
                self.frame_sizes.insert(hir_block.id, 0);
                self.block_to_function.insert(hir_block.id, hir_block.id);
            }
        }

        let mut changed = true;
        while changed {
            changed = false;
            for hir_block in &hir_blocks {
                if let Some(&function) = self.block_to_function.get(&hir_block.id)
                    && let Some(terminator) = &hir_block.terminator
                {
                    let targets = match terminator {
                        HirTerminator::Jump(id) => vec![*id],
                        HirTerminator::Branch {
                            true_block,
                            false_block,
                            ..
                        } => vec![*true_block, *false_block],
                        HirTerminator::Return(_, _) => vec![],
                        HirTerminator::IntReturn => vec![],
                    };
                    for target in targets {
                        if let hash_map::Entry::Vacant(entry) = self.block_to_function.entry(target)
                        {
                            entry.insert(function);
                            changed = true;
                        }
                    }
                }
            }
        }

        for hir_block in hir_blocks {
            self.current_function = self.block_to_function.get(&hir_block.id).copied();

            let mut lir_instructions = Vec::new();
            for instruction in hir_block.instructions {
                self.lower_instruction(instruction, &mut lir_instructions);
            }

            if let Some(terminator) = hir_block.terminator {
                self.lower_terminator(terminator, &mut lir_instructions);
            }

            self.blocks.push(LirBlock {
                id: hir_block.id,
                instructions: lir_instructions,
            });
        }
        self.current_function = None;
    }

    fn lower_instruction(&mut self, instruction: HirInstruction, out: &mut Vec<LirInstruction>) {
        match instruction {
            HirInstruction::LoadGlobal {
                destination,
                id,
                word_size,
            } => {
                let address = self.get_global_address(id);
                let destination = self.lower_operand(destination);
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: LirOperand::IndirectDirect(address),
                    destination,
                });
            }

            HirInstruction::StoreGlobal {
                id,
                value,
                word_size,
            } => {
                let value_operand = self.lower_operand(value);
                let address = self.get_global_address(id);
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: value_operand,
                    destination: LirOperand::IndirectDirect(address),
                });
            }
            HirInstruction::BinaryOperator {
                destination,
                left,
                operator,
                right,
                word_size,
            } => {
                let destination = self.lower_operand(destination);
                let left = self.lower_operand(left);
                let right = self.lower_operand(right);

                match &operator {
                    HirBinaryOperator::Assign => {}
                    HirBinaryOperator::Add => {
                        out.push(LirInstruction::Add {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::Sub => {
                        out.push(LirInstruction::Sub {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::Multiply => {
                        out.push(LirInstruction::Mul {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::Divide => {
                        out.push(LirInstruction::Div {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::Remainder => {
                        out.push(LirInstruction::Rem {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::BitwiseAnd => {
                        out.push(LirInstruction::And {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::BitwiseOr => {
                        out.push(LirInstruction::Or {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::BitwiseXor => {
                        out.push(LirInstruction::Xor {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::LeftShift => {
                        out.push(LirInstruction::Lsl {
                            size: word_size,
                            source: left,
                            count: right,
                            destination: destination.clone(),
                        });
                    }
                    HirBinaryOperator::RightShift => {
                        out.push(LirInstruction::Lsr {
                            size: word_size,
                            source: left,
                            count: right,
                            destination: destination.clone(),
                        });
                    }
                    HirBinaryOperator::VectorAdd
                    | HirBinaryOperator::VectorSub
                    | HirBinaryOperator::VectorMultiply
                    | HirBinaryOperator::VectorDivide
                    | HirBinaryOperator::VectorRemainder
                    | HirBinaryOperator::VectorAnd
                    | HirBinaryOperator::VectorOr
                    | HirBinaryOperator::VectorXor
                    | HirBinaryOperator::VectorEqual
                    | HirBinaryOperator::VectorNotEqual
                    | HirBinaryOperator::VectorLess
                    | HirBinaryOperator::VectorLessEqual
                    | HirBinaryOperator::VectorGreater
                    | HirBinaryOperator::VectorGreaterEqual => {
                        out.push(LirInstruction::Mov {
                            size: WordSize::Long,
                            source: self.heap_pointer.clone(),
                            destination: destination.clone(),
                        });
                        out.push(LirInstruction::Add {
                            size: WordSize::Long,
                            left: self.heap_pointer.clone(),
                            right: LirOperand::Direct(4),
                            destination: self.heap_pointer.clone(),
                        });
                        match &operator {
                            HirBinaryOperator::VectorAdd => out.push(LirInstruction::VAdd {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorSub => out.push(LirInstruction::VSub {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorMultiply => out.push(LirInstruction::VMul {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorDivide => out.push(LirInstruction::VDiv {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorRemainder => out.push(LirInstruction::VRem {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorAnd => out.push(LirInstruction::VAnd {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorOr => out.push(LirInstruction::VOr {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorXor => out.push(LirInstruction::VXor {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorEqual => out.push(LirInstruction::VCmpBeq {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorNotEqual => {
                                out.push(LirInstruction::VCmpBne {
                                    left,
                                    right,
                                    destination,
                                })
                            }
                            HirBinaryOperator::VectorLess => out.push(LirInstruction::VCmpBlt {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorLessEqual => {
                                out.push(LirInstruction::VCmpBle {
                                    left,
                                    right,
                                    destination,
                                })
                            }
                            HirBinaryOperator::VectorGreater => out.push(LirInstruction::VCmpBgt {
                                left,
                                right,
                                destination,
                            }),
                            HirBinaryOperator::VectorGreaterEqual => {
                                out.push(LirInstruction::VCmpBge {
                                    left,
                                    right,
                                    destination,
                                })
                            }
                            _ => unreachable!(),
                        }
                    }
                    HirBinaryOperator::And => {
                        out.push(LirInstruction::And {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::Or => {
                        out.push(LirInstruction::Or {
                            size: word_size,
                            left,
                            right,
                            destination,
                        });
                    }
                    HirBinaryOperator::Equal
                    | HirBinaryOperator::NotEqual
                    | HirBinaryOperator::Less
                    | HirBinaryOperator::LessEqual
                    | HirBinaryOperator::Greater
                    | HirBinaryOperator::GreaterEqual => {
                        out.push(LirInstruction::Cmp {
                            size: word_size,
                            that: right,
                            with: left,
                        });

                        let condition = match operator {
                            HirBinaryOperator::Equal => Condition::Equal,
                            HirBinaryOperator::NotEqual => Condition::NotEqual,
                            HirBinaryOperator::Less => Condition::Lower,
                            HirBinaryOperator::LessEqual => Condition::LowerEqual,
                            HirBinaryOperator::Greater => Condition::Greater,
                            HirBinaryOperator::GreaterEqual => Condition::GreaterEqual,
                            _ => unreachable!(),
                        };

                        out.push(LirInstruction::SetBool {
                            condition,
                            destination: destination.clone(),
                        });
                    }
                }
            }
            HirInstruction::Call {
                destination,
                block,
                arguments,
            } => {
                self.save_registers(out);

                let arguments_count = arguments.len();
                let mut arguments_size = 0;
                for (argument, word_size) in arguments.into_iter().rev() {
                    let operand = self.lower_operand(argument);
                    arguments_size += 1;
                    out.push(LirInstruction::Mov {
                        size: word_size,
                        source: operand,
                        destination: LirOperand::IndirectPreDecrement(Box::new(
                            self.stack_pointer.clone(),
                        )),
                    });
                }

                out.push(LirInstruction::Call { label: block });

                if arguments_count > 0 {
                    out.push(LirInstruction::Add {
                        size: WordSize::Long,
                        left: self.stack_pointer.clone(),
                        right: LirOperand::Direct(arguments_size),
                        destination: self.stack_pointer.clone(),
                    });
                }

                self.restore_registers(out);

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.return_registers.clone(),
                    destination: self.get_virtual_register(destination),
                });
            }
            HirInstruction::CallPrologue => {
                if let Some(entry) = self.current_function {
                    self.frame_sizes.entry(entry).or_insert(0);
                }

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.frame_pointer.clone(),
                    destination: LirOperand::IndirectPreDecrement(Box::new(
                        self.stack_pointer.clone(),
                    )),
                });

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.stack_pointer.clone(),
                    destination: self.frame_pointer.clone(),
                });

                out.push(LirInstruction::AllocateStackFrame);
            }
            HirInstruction::InterruptPrologue => {
                if let Some(entry) = self.current_function {
                    self.frame_sizes.entry(entry).or_insert(0);
                }

                self.save_registers(out);

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.frame_pointer.clone(),
                    destination: LirOperand::IndirectPreDecrement(Box::new(
                        self.stack_pointer.clone(),
                    )),
                });

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.stack_pointer.clone(),
                    destination: self.frame_pointer.clone(),
                });

                out.push(LirInstruction::AllocateStackFrame);
            }
            HirInstruction::AllocateStack { slot } => {
                let entry = self
                    .current_function
                    .expect("Stack allocation outside of function context");
                let size = self.frame_sizes.get_mut(&entry).unwrap();
                *size += 1;
                self.stack_offsets.insert(slot, -*size);
            }
            HirInstruction::StoreStack {
                slot,
                value,
                word_size,
            } => {
                let offset = *self.stack_offsets.get(&slot).unwrap() as u64;
                let value_operand = self.lower_operand(value);
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: value_operand,
                    destination: LirOperand::IndirectOffset {
                        base: Box::new(self.frame_pointer.clone()),
                        offset: Box::new(LirOperand::Direct(offset)),
                    },
                });
            }
            HirInstruction::LoadStack {
                destination,
                slot,
                word_size,
            } => {
                let offset = *self.stack_offsets.get(&slot).unwrap() as u64;
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: LirOperand::IndirectOffset {
                        base: Box::new(self.frame_pointer.clone()),
                        offset: Box::new(LirOperand::Direct(offset)),
                    },
                    destination: self.get_virtual_register(destination),
                });
            }
            HirInstruction::LoadField {
                destination,
                object,
                offset,
                word_size,
            } => {
                let object = self.lower_operand(object);
                let base = self.operand_to_register(object, RegisterType::Address, out);
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: LirOperand::IndirectOffset {
                        base: Box::new(base),
                        offset: Box::new(LirOperand::Direct(offset)),
                    },
                    destination: self.get_virtual_register(destination),
                });
            }
            HirInstruction::StoreField {
                object,
                offset,
                value,
                word_size,
            } => {
                let object = self.lower_operand(object);
                let value = self.lower_operand(value);
                let base = self.operand_to_register(object, RegisterType::Address, out);
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: value,
                    destination: LirOperand::IndirectOffset {
                        base: Box::new(base),
                        offset: Box::new(LirOperand::Direct(offset)),
                    },
                });
            }
            HirInstruction::AllocateObject { destination, size } => {
                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.heap_pointer.clone(),
                    destination: self.get_virtual_register(destination),
                });

                out.push(LirInstruction::Add {
                    size: WordSize::Long,
                    left: self.heap_pointer.clone(),
                    right: LirOperand::Direct(size),
                    destination: self.heap_pointer.clone(),
                });
            }
            HirInstruction::Input {
                destination,
                port,
                word_size,
            } => {
                let port = Self::lower_constant_to_direct(port);
                let destination = self.lower_operand(destination);
                out.push(LirInstruction::In {
                    port,
                    destination,
                    word_size,
                })
            }
            HirInstruction::Output {
                port,
                value,
                word_size,
            } => {
                let port = Self::lower_constant_to_direct(port);
                let value = self.lower_operand(value);
                out.push(LirInstruction::Out {
                    port,
                    value,
                    word_size,
                })
            }
            HirInstruction::LoadIndex {
                destination,
                array,
                index,
                word_size,
            } => {
                let destination = self.lower_operand(destination);
                let array = self.lower_operand(array);
                let index = self.lower_operand(index);

                let base = self.operand_to_register(array, RegisterType::Address, out);
                let offset = self.operand_to_register(index, RegisterType::Data, out);
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: LirOperand::IndirectOffset {
                        base: Box::new(base),
                        offset: Box::new(offset),
                    },
                    destination,
                })
            }
            HirInstruction::StoreIndex {
                array,
                index,
                value,
                word_size,
            } => {
                let array = self.lower_operand(array);
                let index = self.lower_operand(index);
                let value = self.lower_operand(value);

                let base = self.operand_to_register(array, RegisterType::Address, out);
                let offset = self.operand_to_register(index, RegisterType::Data, out);
                out.push(LirInstruction::Mov {
                    size: word_size,
                    source: value,
                    destination: LirOperand::IndirectOffset {
                        base: Box::new(base),
                        offset: Box::new(offset),
                    },
                })
            }
            HirInstruction::AllocateArray { destination, size } => {
                let destination = self.lower_operand(destination);

                out.push(LirInstruction::Add {
                    size: WordSize::Long,
                    left: self.heap_pointer.clone(),
                    right: LirOperand::Direct(3),
                    destination: self.heap_pointer.clone(),
                });
                out.push(LirInstruction::And {
                    size: WordSize::Long,
                    left: self.heap_pointer.clone(),
                    right: LirOperand::Direct(0xFFFFFFFFFFFFFFFC),
                    destination: self.heap_pointer.clone(),
                });

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.heap_pointer.clone(),
                    destination,
                });
                out.push(LirInstruction::Add {
                    size: WordSize::Long,
                    left: self.heap_pointer.clone(),
                    right: LirOperand::Direct(size),
                    destination: self.heap_pointer.clone(),
                });
            }
            HirInstruction::StoreSlice {
                target,
                start,
                value,
                size,
                word_size,
            } => {
                let target = self.lower_operand(target);
                let value = self.lower_operand(value);
                let start = self.lower_operand(start);

                let destination = self.new_virtual_address_register();
                out.push(LirInstruction::Add {
                    size: WordSize::Long,
                    left: target,
                    right: start,
                    destination: destination.clone(),
                });

                let base = self.operand_to_register(value, RegisterType::Address, out);
                for i in 0..size {
                    out.push(LirInstruction::Mov {
                        size: word_size.clone(),
                        source: LirOperand::IndirectOffset {
                            base: Box::new(base.clone()),
                            offset: Box::new(LirOperand::Direct(i)),
                        },
                        destination: LirOperand::IndirectOffset {
                            base: Box::new(destination.clone()),
                            offset: Box::new(LirOperand::Direct(i)),
                        },
                    });
                }
            }
            HirInstruction::LoadSlice {
                destination,
                array,
                start,
                ..
            } => {
                let destination = self.lower_operand(destination);
                let array = self.lower_operand(array);
                let start = self.lower_operand(start);
                out.push(LirInstruction::Add {
                    size: WordSize::Long,
                    left: array,
                    right: start,
                    destination,
                })
            }
            HirInstruction::Not {
                destination,
                operand,
                word_size,
            } => {
                let destination = self.lower_operand(destination);
                let operand = self.lower_operand(operand);

                out.push(LirInstruction::Not {
                    size: word_size,
                    source: operand,
                    destination,
                });
            }
            HirInstruction::CopyConstantArray {
                destination,
                id,
                word_size,
            } => {
                let destination = self.lower_operand(destination);
                let array_const = &self.array_constants[id];
                let base = array_const.base_address;
                let size = array_const.values.len() as u64;

                for i in 0..size {
                    out.push(LirInstruction::Mov {
                        size: word_size.clone(),
                        source: LirOperand::IndirectDirect(base + i),
                        destination: LirOperand::IndirectOffset {
                            base: Box::new(destination.clone()),
                            offset: Box::new(LirOperand::Direct(i)),
                        },
                    });
                }
            }
        }
    }

    fn lower_constant_to_direct(constant: HirOperand) -> LirOperand {
        if let HirOperand::Constant(constant, _) = constant {
            LirOperand::Direct(constant.parse::<u64>().unwrap())
        } else {
            panic!("Operand is not a constant");
        }
    }

    fn lower_terminator(&mut self, terminator: HirTerminator, out: &mut Vec<LirInstruction>) {
        match terminator {
            HirTerminator::Jump(block_id) => {
                out.push(LirInstruction::Jmp { label: block_id });
            }
            HirTerminator::Branch {
                condition,
                true_block,
                false_block,
            } => {
                let condition = self.lower_operand(condition);

                out.push(LirInstruction::Cmp {
                    size: WordSize::Byte,
                    that: condition,
                    with: LirOperand::Direct(1),
                });

                out.push(LirInstruction::Branch {
                    condition: Condition::Equal,
                    label: true_block,
                });

                out.push(LirInstruction::Jmp { label: false_block });
            }
            HirTerminator::Return(operand, word_size) => {
                if let Some(operand) = operand {
                    let return_value = self.lower_operand(operand);
                    out.push(LirInstruction::Mov {
                        size: word_size,
                        source: return_value,
                        destination: self.return_registers.clone(),
                    });
                }

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.frame_pointer.clone(),
                    destination: self.stack_pointer.clone(),
                });

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: LirOperand::IndirectPostIncrement(Box::new(self.stack_pointer.clone())),
                    destination: self.frame_pointer.clone(),
                });

                out.push(LirInstruction::Ret);
            }
            HirTerminator::IntReturn => {
                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: self.frame_pointer.clone(),
                    destination: self.stack_pointer.clone(),
                });

                out.push(LirInstruction::Mov {
                    size: WordSize::Long,
                    source: LirOperand::IndirectPostIncrement(Box::new(self.stack_pointer.clone())),
                    destination: self.frame_pointer.clone(),
                });

                self.restore_registers(out);

                out.push(LirInstruction::IntRet);
            }
        }
    }

    fn create_entry_point(&mut self, main_block_id: BlockId) {
        let instructions = vec![
            LirInstruction::Mov {
                size: WordSize::Long,
                source: LirOperand::Direct(99999),
                destination: self.stack_pointer.clone(),
            },
            LirInstruction::Mov {
                size: WordSize::Long,
                source: LirOperand::Direct(1000),
                destination: self.heap_pointer.clone(),
            },
            LirInstruction::Call {
                label: main_block_id,
            },
            LirInstruction::Halt,
        ];

        let entry_block = LirBlock {
            id: BlockId::MAX,
            instructions,
        };

        self.blocks.insert(0, entry_block);
    }
}

fn normalize_constant(value_str: String) -> String {
    match value_str.as_str() {
        "true" => "1".to_string(),
        "false" => "0".to_string(),
        s if s.starts_with('\'') && s.ends_with('\'') && s.len() >= 3 => {
            let inner = &s[1..s.len() - 1];
            let char_value = match inner {
                "\\n" => '\n' as u64,
                "\\r" => '\r' as u64,
                "\\t" => '\t' as u64,
                "\\\\" => '\\' as u64,
                "\\'" => '\'' as u64,
                "\\0" => 0_u64,
                _ => inner.chars().next().unwrap_or('\0') as u64,
            };
            char_value.to_string()
        }
        _ => value_str,
    }
}

pub struct LirPackage {
    pub text_section: Vec<LirBlock>,
    pub data_section: HashMap<Address, (u64, WordSize)>,
    pub interrupt_blocks: [BlockId; 8],
}

pub fn compile_lir(control_flow_graph: ControlFlowGraph) -> LirPackage {
    let mut context = LirContext::new(control_flow_graph.register_counter);

    for (values, element_type) in control_flow_graph.array_constants {
        let length = values.len() as u64;
        context.array_constants.push(ArrayConstant {
            values,
            element_type,
            base_address: context.data_size,
        });
        context.data_size += length;
    }

    let entry_point = control_flow_graph.entry_block;
    context.lower(control_flow_graph.blocks);
    context.create_entry_point(entry_point);

    context.compile_virtual_registers();

    let mut data_section = HashMap::new();
    for ((name, _), (address, word_size)) in context.constants {
        let value = name.parse::<i64>().unwrap() as u64;
        data_section.insert(address, (value, word_size));
    }

    for array in &context.array_constants {
        let word_size = match array.element_type {
            Type::Bool | Type::Char => WordSize::Byte,
            _ => WordSize::Long,
        };
        for (i, value_str) in array.values.iter().enumerate() {
            let normalized = normalize_constant(value_str.clone());
            let value = normalized.parse::<i64>().unwrap_or(0) as u64;
            data_section.insert(array.base_address + i as u64, (value, word_size.clone()));
        }
    }

    LirPackage {
        text_section: context.blocks,
        data_section,
        interrupt_blocks: control_flow_graph.interrupt_blocks,
    }
}
