int Main() {
    if (false) {
        return 1;
    }
    else if (true) {
        return 2;
    }
    else {
        return 3;
    }
}
